﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebApplication1.Models
{
    public class CountryModel
    {
        public List<SelectListItem> CountryList { get; set; }
        public List<int> SelectedCountryId { get; set; }
        public CountryModel()
        {
            CountryList = new List<SelectListItem>();
            SelectedCountryId = new List<int>();
        }
    }
}