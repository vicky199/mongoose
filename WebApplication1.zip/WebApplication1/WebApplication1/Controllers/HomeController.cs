﻿using System.Collections.Generic;
using System.Web.Mvc;
using WebApplication1.Models;
namespace WebApplication1.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            CountryModel objcountrymodel = new CountryModel();
            objcountrymodel.CountryList.Add(new SelectListItem { Text = "No", Value = "1" });
            objcountrymodel.CountryList.Add(new SelectListItem { Text = "yah", Value = "2" });
            objcountrymodel.CountryList.Add(new SelectListItem{ Text = "Yes", Value = "3" });
            objcountrymodel.SelectedCountryId.Add(1);
            objcountrymodel.SelectedCountryId.Add(3);
            return View(objcountrymodel);
        }
        [HttpPost]
        public ActionResult saveCountry(CountryModel c)
        {
            return View();
        }
    }
}